from distutils.core import setup

setup(name='shortcoding',
      version='2.0.0.0',
      packages=['shortcoding'],
      maintainer='Neeky',
      maintainer_email='neeky@live.com',
      url='https://github.com/Neeky/shortcoding',
      python_requires='>=3.1.*,'
      )


      